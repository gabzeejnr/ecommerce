import fallBack from "../../assets/Products/fallback.jpg";
import AddToCart from "../AddToCart/AddToCart.jsx";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faHeart } from "@fortawesome/free-solid-svg-icons";
import styles from "./Products.module.scss";
import { useState, useEffect } from "react";
import { getShoes } from "../../services/services.js";

export default function Products({ likeCount, setLikeCount }) {

    const [isLiked, setIsLiked] = useState(false)
    const [shoeData, setShoeData] = useState([])


    useEffect(() => {

        async function fetchData() {
            const data = await getShoes();
            setShoeData(data.shoes);
        }
        fetchData();

    }, [])

    function increaseLike(e) {
        setLikeCount(prev => prev + 1)
        console.log(likeCount);
        e.currentTarget(setIsLiked(prev => !prev))
    }

    return (
        <section className={styles.products}>
            {shoeData.map(shoe => (
                <div className={styles.product} key={shoe.id}>
                    <div className={styles["image-holder"]}>
                        <div className={styles["hovered-element"]}>
                            <div className={isLiked ? styles.liked : styles.heart} onClick={(e) => increaseLike(e)}>
                                <FontAwesomeIcon icon={faHeart} />
                            </div>
                            <button>
                                <FontAwesomeIcon icon={faEye} />
                                &ensp; View details
                            </button>
                        </div>

                        <img id="images" src={shoe.image ? `/Products/${shoe.image}` : fallBack} alt={shoe.image ? shoe.name : "Fall-back image"} />
                    </div>
                    <div className={styles["detail-wrapper"]}>
                        <div className={styles.details}>
                            <span className={styles.name}>{shoe.name}</span>
                            <span className={styles.price}>${shoe.price}</span>
                        </div>
                        <AddToCart />
                    </div>
                </div>
            ))}
        </section>
    )
}